const products = [
  { id: 1, name: 'Premium Headphones', sales: 1245, revenue: '$124,500', growth: '+12%' },
  { id: 2, name: 'Wireless Mouse', sales: 2103, revenue: '$84,120', growth: '+8%' },
  { id: 3, name: 'Mechanical Keyboard', sales: 892, revenue: '$89,200', growth: '+15%' },
  { id: 4, name: 'USB-C Hub', sales: 1567, revenue: '$62,680', growth: '+5%' },
  { id: 5, name: 'Laptop Stand', sales: 743, revenue: '$44,580', growth: '+22%' },
];

export function TopProducts() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl mb-4">Top Products</h2>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-3 px-2">Product</th>
              <th className="text-right py-3 px-2">Sales</th>
              <th className="text-right py-3 px-2">Revenue</th>
              <th className="text-right py-3 px-2">Growth</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id} className="border-b last:border-0">
                <td className="py-3 px-2">{product.name}</td>
                <td className="text-right py-3 px-2">{product.sales}</td>
                <td className="text-right py-3 px-2">{product.revenue}</td>
                <td className="text-right py-3 px-2 text-green-600">{product.growth}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
