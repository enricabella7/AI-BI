import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { month: 'Jan', sales: 45000, revenue: 52000 },
  { month: 'Feb', sales: 52000, revenue: 61000 },
  { month: 'Mar', sales: 48000, revenue: 55000 },
  { month: 'Apr', sales: 61000, revenue: 72000 },
  { month: 'May', sales: 55000, revenue: 65000 },
  { month: 'Jun', sales: 67000, revenue: 78000 },
  { month: 'Jul', sales: 72000, revenue: 84000 },
  { month: 'Aug', sales: 68000, revenue: 79000 },
  { month: 'Sep', sales: 75000, revenue: 88000 },
  { month: 'Oct', sales: 81000, revenue: 95000 },
  { month: 'Nov', sales: 78000, revenue: 91000 },
  { month: 'Dec', sales: 89000, revenue: 105000 },
];

export function SalesChart() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl mb-4">Sales Overview</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="sales" stroke="#3b82f6" strokeWidth={2} />
          <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
