import { DollarSign, ShoppingCart, Users, TrendingUp } from 'lucide-react';
import { MetricCard } from './components/MetricCard';
import { SalesChart } from './components/SalesChart';
import { TopProducts } from './components/TopProducts';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl">Sales Dashboard</h1>
          <p className="text-gray-600 mt-1">Track your sales performance and metrics</p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Total Revenue"
            value="$847,352"
            change="12.5% from last month"
            isPositive={true}
            icon={DollarSign}
          />
          <MetricCard
            title="Total Orders"
            value="1,429"
            change="8.2% from last month"
            isPositive={true}
            icon={ShoppingCart}
          />
          <MetricCard
            title="New Customers"
            value="342"
            change="3.1% from last month"
            isPositive={false}
            icon={Users}
          />
          <MetricCard
            title="Growth Rate"
            value="23.8%"
            change="4.3% from last month"
            isPositive={true}
            icon={TrendingUp}
          />
        </div>

        {/* Charts and Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="lg:col-span-2">
            <SalesChart />
          </div>
          <div className="lg:col-span-2">
            <TopProducts />
          </div>
        </div>
      </div>
    </div>
  );
}
